import { combineReducers } from "redux";
import api from "./api";

export default combineReducers({
  api
});
